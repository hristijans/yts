ng-resource
===========

An alternative angular resource.
